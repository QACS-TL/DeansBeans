package deansBeansBusinessObjectsTests;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import deansBeansBusinessObjects.BasketItem;
import deansBeansBusinessObjects.OrderBasket;
import deansBeansDataLayer.models.Customer;
import deansBeansDataLayer.models.Format;

class Task1SectionCUnitTests {
	  Customer customer = new Customer(12345, "Smith", "1 the High Street", "Bootle",
	  "Lancs", "BOO 12T", "01273 700349", "Smith@Bootle.com", "Foo", "Bar");
	  
	  @Test 
	  public void AddTwoOfTheSameProduct() { 
 		  OrderBasket orderBasket = new OrderBasket(customer);
		  
          int productID = 1;
	      String productName = "Old Knobler";
	      BigDecimal wholesalePrice = new BigDecimal(1.00);
	      BigDecimal recommendedRetailPrice = new BigDecimal(15.99);
	      int quantity = 1;
          int formatID = 3;
          int degreeOfRoastID = 4;
	      String description = "Old Knobler is the original classic";
		  
	      BasketItem basketItem = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
	
		  orderBasket.addItem(basketItem);
		  
          productID = 2;
	      productName = "Dean's Eye Opener";
	      wholesalePrice = new BigDecimal(1.00);
	      recommendedRetailPrice = new BigDecimal(1.99);
	      quantity = 2;
          formatID = 3;
          degreeOfRoastID = 4;
	      description = "Dean's Eye Opener, the everyday coffee";
		  
	      basketItem = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  
		  orderBasket.addItem(basketItem); 
	  
          productID = 3;
	      productName = "Robusta Crusta";
	      wholesalePrice = new BigDecimal(12.00);
	      recommendedRetailPrice = new BigDecimal(26.99);
	      quantity = 3;
          formatID = 4;
          degreeOfRoastID = 5;
	      description = "The Breakfast Opener";
		  
	      basketItem = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  
		  orderBasket.addItem(basketItem); 
		  
          productID = 2;
	      productName = "Dean's Eye Opener";
	      wholesalePrice = new BigDecimal(1.00);
	      recommendedRetailPrice = new BigDecimal(1.99);
	      quantity = 2;
          formatID = 3;
          degreeOfRoastID = 4;
	      description = "Dean's Eye Opener, the everyday coffee";
		  
	      basketItem = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  
		  orderBasket.addItem(basketItem); 
	  
		  assertEquals(3, orderBasket.getNumberOfProducts()); 
		  assertEquals(8, orderBasket.getNumberOfItems()); 
	  }
	  
	  
	  @Test public void AddManyOfTheSameProductButDifferentFormatsAndDegreesOfRoast() { 
		  OrderBasket orderBasket = new OrderBasket(customer);
		  
          int productID = 1;
	      String productName = "Old Knobler";
	      BigDecimal wholesalePrice = new BigDecimal(7.00);
	      BigDecimal recommendedRetailPrice = new BigDecimal(15.99);
	      int quantity = 2;
          int formatID = 3;
          int degreeOfRoastID = 4;
	      String  discountType = null;
	      String description = "Old Knobler is the original classic";
		  
	      BasketItem basketItem1 = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
	
		  orderBasket.addItem(basketItem1);
		  
		  productID = 1;
	      productName = "Dean's Eye Opener";
	      recommendedRetailPrice = new BigDecimal(1.99);
	      quantity = 2;
          formatID = 4;
          degreeOfRoastID = 4;
	      discountType = null;
	      description = "Dean's Eye Opener, the everyday coffee";
		  
	      BasketItem basketItem2 = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  
		  orderBasket.addItem(basketItem2); 
	  
		  productID = 1;
	      productName = "Robusta Crusta";
	      recommendedRetailPrice = new BigDecimal(26.99);
	      quantity = 2;
          formatID = 4;
          degreeOfRoastID = 5;
	      discountType = null;
	      description = "The Breakfast Opener";
		  
	      BasketItem basketItem3 = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  
		  orderBasket.addItem(basketItem3); 
		  
		  productID = 1;
	      productName = "Dean's Eye Opener";
	      recommendedRetailPrice = new BigDecimal(1.99);
	      quantity = 2;
          formatID = 5;
          degreeOfRoastID = 5;
	      discountType = null;
	      description = "Dean's Eye Opener, the everyday coffee";
		  
	      BasketItem basketItem4 = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  orderBasket.addItem(basketItem4); 
		  
		  productID = 1;
	      productName = "Dean's Eye Opener";
	      recommendedRetailPrice = new BigDecimal(1.99);
	      quantity = 2;
          formatID = 3;
          degreeOfRoastID = 4;
	      discountType = null;
	      description = "Dean's Eye Opener, the everyday coffee";
		  
	      BasketItem basketItem5 = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		  orderBasket.addItem(basketItem5); 
		  
	  
		  assertEquals(4, orderBasket.getNumberOfProducts()); 
		  assertEquals(10, orderBasket.getNumberOfItems()); 
	  }
	 

}
