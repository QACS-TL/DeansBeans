package deansBeansBusinessObjectsTests;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

import deansBeansBusinessObjects.BOGOFBasketItem;
import deansBeansBusinessObjects.BasketItem;
import deansBeansBusinessObjects.IBasketItem;
import deansBeansBusinessObjects.PercentageDiscountBasketItem;
import deansBeansDataLayer.models.Format;

class Task1SectionAAndBUnitTests {
	    /// <summary>
	    ///A test for AddItem passing a quantity of 5
	    ///</summary>
		@Test
		public void increaseQuantityHappyTest()
		{
		   int productID = 5;
		   String productName = "Justa Robusta";
		   BigDecimal wholesalelPrice = new BigDecimal(3.49);
		   BigDecimal recommendedRetailPrice = new BigDecimal(11.60);
		   int quantity = 1;
		   int formatID = 5;
		   int degreeOfRoastID = 2;
		   String description = "Justa Robusta, the everyday coffee";
		
		   BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		   int actual = basketItem.increaseQuantity(5);
		
		   int expected = 6; //Default 1 + 5
		   assertEquals(expected, actual);
		}
	   
		/// <summary>
		///A test for AddItem passing a quantity of 5
		///</summary>
		@Test
		public void increaseQuantitySecondHappyTest()
		{
		   int productID = 5;
		   String productName = "Justa Robusta";
		   BigDecimal wholesalelPrice = new BigDecimal(1.60);
		   BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		   int quantity = 1;
		   int formatID = 5;
		   int degreeOfRoastID = 2;
		   String description = "Justa Robusta, the everyday coffee";
		
		   BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		   int actual = basketItem.increaseQuantity(10);
		
		   int expectedQuantity = 11;//Default 1 + 10
		    
	       BigDecimal expectedTotalItemValue = new BigDecimal(17.60);
	       expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
	        
	       BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
	       actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
 
	       assertEquals(expectedQuantity, basketItem.getQuantity());
	       assertEquals(expectedTotalItemValue,  actualTotalItemValue);
	    }

        /// <summary>
        ///A test for BasketItem Constructor with Zero Quantity
        ///</summary>
		@Test
		public void basketItemZeroQuantityConstructorTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 0;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			});
			  
			//No Assert - Exception Expected    
		}
		   
		/// <summary>
		///A test for BasketItem Constructor with Negative Quantity
		///</summary>
		@Test
		public void basketItemNegativeQuantityConstructorTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = -1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			     BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			});
			  
			//No Assert - Exception Expected    
		}
	   
		/// <summary>
		///A test for AddItem passing no quantity amount
		///</summary>
		@Test
		public void increaseQuantityByZero()
		{
			int productID = 5;
			String productName = "Justa Robusta";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(11.60);
			int quantity = 2;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Justa Robusta, the everyday coffee";
			
			BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				int actual = basketItem.increaseQuantity(0);
			});
			  
			//No Assert - Exception Expected
		}
		
		/// <summary>
		///A test for increaeQuantity passing negative quantity amount
		///</summary>
		@Test
		public void increaseQuantityByNegativeAmount()
		{
			int productID = 5;
			String productName = "Justa Robusta";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(11.60);
			int quantity = 2;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Justa Robusta, the everyday coffee";
			
			BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				int actual = basketItem.increaseQuantity(-2);
			});
			  
			//No Assert - Exception Expected
		}
		
		/// <summary>
		///A test for decreaseQuantity passing negative quantity amount
		///</summary>
		@Test
		public void decreaseQuantityByNegativeAmount()
		{
			int productID = 5;
			String productName = "Justa Robusta";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(11.60);
			int quantity = 2;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Justa Robusta, the everyday coffee";
			
			BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				int actual = basketItem.decreaseQuantity(-2);
			});
			  
			//No Assert - Exception Expected
		}
		
		/// <summary>
		///A happy test for decreaseQuantity
		///</summary>
		@Test
		public void decreaseQuantityHappyTest()
		{
			int productID = 5;
			String productName = "Justa Robusta";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(11.60);
			int quantity = 4;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Justa Robusta, the everyday coffee";
			
			BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			
			int actual = basketItem.decreaseQuantity(2);
			
			int expected = 2; //Default 4 - 2
			assertEquals(expected, actual);
		}
		
		/// <summary>
		///A test for decreasing the quantity to zero
		///</summary>
		@Test
		public void decreaseQuantityToZero()
		{
			int productID = 5;
			String productName = "Justa Robusta";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(11.60);
			int quantity = 5;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Justa Robusta, the everyday coffee";
			
			BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			
            int quantityToRemove = 5;
			
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				int actual = basketItem.decreaseQuantity(quantityToRemove);
			});
			
			//No Assert - Exception Expected
		}
		
		/// <summary>
		///A test for BasketItem Constructor with Negative WholesalePrice
		///</summary>
		@Test
		public void basketItemNegativeWholesalePriceConstructorTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(-3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			     BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			});
			  
			//No Assert - Exception Expected    
		}
		
		/// <summary>
		///A test for BasketItem Constructor with Zero WholesalePrice
		///</summary>
		@Test
		public void basketItemZeroWholesalePriceConstructorTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(0.00);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			     BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			});
			  
			//No Assert - Exception Expected    
		}
		
		
		/// <summary>
		///A test for BasketItem with positive value passed to IncreaseQuantity method
		///</summary>
		@Test
		public void basketItemPositiveIncreaseQuantityTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
			
			BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			
			int actual = basketItem.increaseQuantity(1);
			
			int expected = 2; //Default 4 - 2
			assertEquals(expected, actual);
		}
		
		/// <summary>
		///A test for BasketItem with Negative value passed to IncreaseQuantity method
		///</summary>
		@Test
		public void basketItemNegativeIncreaseQuantityTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				basketItem.increaseQuantity(-1);
			});
			  
			//No Assert - Exception Expected    
		}
		
        /// <summary>
        ///A test for BasketItem with positive value passed to DecreaseQuantity method
        ///</summary>
		@Test
		public void basketItemPositiveDecreaseQuantityTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 4;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			basketItem.decreaseQuantity(1);
			int expectedQuantity = 3;
			
			assertEquals(expectedQuantity, basketItem.getQuantity());
		} 
		
		/// <summary>
		///A test for BasketItem with too large a value passed to DecreaseQuantity method
		///</summary>
		@Test
		public void basketItemDecreaseByMoreThanTheQuantityTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 4;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				basketItem.decreaseQuantity(5);
			});
			  
			//No Assert - Exception Expected    
		}
		
		/// <summary>
		///A test for BasketItem with Negative value passed to DecreaseQuantity method
		///</summary>
		@Test
		public void basketItemNegativeDecreaseQuantityTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				basketItem.decreaseQuantity(-1);
			});
			  
			//No Assert - Exception Expected    
		}		
		
        /// <summary>
        ///A test for BasketItem with positive value passed to IncreaseDegreeOfRoast method
        ///</summary>
		@Test
		public void basketItemPositiveIncreaseDegreeOfRoastTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 4;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			basketItem.increaseDegreeOfRoast(2);
			int expectedDegreeOfRoastID = 4;
			
			assertEquals(expectedDegreeOfRoastID, basketItem.getDegreeOfRoastID());
		} 
		
		/// <summary>
		///A test for BasketItem with Negative value passed to IncreaseDegreeOfRoast method
		///</summary>
		@Test
		public void basketItemNegativeIncreaseDegreeOfRoastTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				basketItem.increaseDegreeOfRoast(-1);
			});
			  
			//No Assert - Exception Expected    
		}	
		
		
        /// <summary>
        ///A test for BasketItem with positive value passed to DecreaseDegreeOfRoast method
        ///</summary>
		@Test
		public void basketItemPositiveDecreaseDegreeOfRoastTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 4;
			int formatID = 5;
			int degreeOfRoastID = 5;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			basketItem.decreaseDegreeOfRoast(2);
			int expectedDegreeOfRoastID = 3;
			
			assertEquals(expectedDegreeOfRoastID, basketItem.getDegreeOfRoastID());
		}
		
		/// <summary>
		///A test for BasketItem with too large a value passed to DecreaseDegreeOfRoast method
		///</summary>
		@Test
		public void basketItemDecreaseByMoreThanTheDegreeOfRoastTest()
		{
			int productID = 1;
			String productName = "Old Knobler";
			BigDecimal wholesalelPrice = new BigDecimal(3.49);
			BigDecimal recommendedRetailPrice = new BigDecimal(12.49);
			int quantity = 1;
			int formatID = 5;
			int degreeOfRoastID = 2;
			String description = "Old Knobler is the original classic";
		    BasketItem basketItem = new BasketItem(productID, productName, wholesalelPrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
			  
			Exception exception = assertThrows(IllegalArgumentException.class, () -> {
				basketItem.decreaseDegreeOfRoast(5);
			});
			  
			//No Assert - Exception Expected    
		}	
}
