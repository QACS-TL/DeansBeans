package deansBeansBusinessObjectsTests;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

import deansBeansBusinessObjects.BOGOFBasketItem;
import deansBeansBusinessObjects.BasketItem;
import deansBeansBusinessObjects.FFTPOTBasketItem;
import deansBeansBusinessObjects.IBasketItem;
import deansBeansBusinessObjects.OrderBasket;
import deansBeansBusinessObjects.PercentageDiscountBasketItem;
import deansBeansBusinessObjects.TFTPOTBasketItem;
import deansBeansDataLayer.models.Customer;
import deansBeansDataLayer.models.Format;

class Task2DiscountTests {
   
	   @Test
	   public void  totalValueOfUndiscountedBasketItemTest()
	   {
       int productID = 5;
	      String productName = "Old Knobler";
	      BigDecimal wholesalePrice = new BigDecimal(1.00);
	      BigDecimal recommendedRetailPrice = new BigDecimal(2.00);
	      int quantity = 2;
	      int formatID = 3;
	      int degreeOfRoastID = 5;
	       String description = "Old Knobler is the original classic";
	       
	       BasketItem basketItem = basketItem = new BasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

	      BigDecimal expectedTotalItemValue = new BigDecimal(2.00);
	      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
	      
	      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
	      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
	      
	      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   }
	   
	   @Test
	   public void percentageDiscountBasketItem()
	   {
          int productID = 5;
	      String productName = "Old Knobler";
	      BigDecimal wholesalePrice = new BigDecimal(1.00);
	      BigDecimal recommendedRetailPrice = new BigDecimal(2.00);
	      int quantity = 2;
	      int formatID = 3;
	      int degreeOfRoastID = 5;
	      String description = "Old Knobler is the original classic";
	      int percentageDiscount = 5;

	      IBasketItem basketItem = new PercentageDiscountBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description, percentageDiscount);

	      BigDecimal expectedTotalItemValue = new BigDecimal(1.90);
	      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
	      
	      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
	      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
	      
	      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 

	   @Test
	   public void bOGOFBasketItemEvenNumber()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.00);
		      BigDecimal recommendedRetailPrice = new BigDecimal(2.00);
		      int quantity = 6;
		      int formatID = 3;
		      int degreeOfRoastID = 5;
		       String description = "Old Knobler is the original classic";
		       
		       BasketItem basketItem = new BOGOFBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(3.00);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 

	   @Test
	   public void bOGOFBasketItemSmallerEvenNumber()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.00);
		      BigDecimal recommendedRetailPrice = new BigDecimal(2.00);
		      int quantity = 2;
		      int formatID = 3;
		      int degreeOfRoastID = 5;
		       String description = "Old Knobler is the original classic";
		       
		       BasketItem basketItem = new BOGOFBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(1.00);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 
	 
	   @Test
	   public void bOGOFBasketItemOddNumber()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.00);
		      BigDecimal recommendedRetailPrice = new BigDecimal(2.00);
		      int quantity = 5;
		      int formatID = 3;
		      int degreeOfRoastID = 5;
		       String description = "Old Knobler is the original classic";
		       
		       BasketItem basketItem = new BOGOFBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(3.00);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 
	   

	   //Three for the price of two tests
	   @Test
	   public void tFTPOTBasketTestForLessThanFourItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 3;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		       String description = "Old Knobler is the original classic";
		       
		       BasketItem basketItem = new TFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(3.20);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 

	   
	   @Test
	   public void tFTPOTBasketTestForFourItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 4;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		       String description = "Old Knobler is the original classic";
		       
		       BasketItem basketItem = new TFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(4.80);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 
	 
	   @Test
	   public void tFTPOTBasketTestMoreThanFourButLessThanEightItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 6;
		      int formatID = 3;
		      int degreeOfRoastID = 2;
		      String description = "Old Knobler is the original classic";
		       
		      BasketItem basketItem = new TFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(6.40);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
		      assertEquals("TFTPOT", basketItem.getDiscountType());
	   } 
 		 
	   @Test
	   public void tFTPOTBasketTestForEightItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 8;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		      String description = "Old Knobler is the original classic";
		       
		      BasketItem basketItem = new TFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(9.60);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
		      assertEquals("TFTPOT", basketItem.getDiscountType());
	   } 

	   //Four for the price of three tests
	   @Test
	   public void fFTPOTBasketTestForLessThanFourItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 3;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		       String description = "Old Knobler is the original classic";
		       
		      IBasketItem basketItem = new FFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(4.80);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 

	   
	   @Test
	   public void fFTPOTBasketTestForFourItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 4;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		       String description = "Old Knobler is the original classic";
		       
		       BasketItem basketItem = new FFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(4.80);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
	   } 
	 
	   @Test
	   public void fFTPOTBasketTestMoreThanFourButLessThanEightItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 7;
		      int formatID = 3;
		      int degreeOfRoastID = 2;
		      String description = "Old Knobler is the original classic";
		       
		      BasketItem basketItem = new FFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(9.60);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
		      assertEquals("FFTPOT", basketItem.getDiscountType());
	   } 
 		 
	   @Test
	   public void fFTPOTBasketTestForEightItems()
	   {
	          int productID = 5;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 8;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		      String description = "Old Knobler is the original classic";
		       
		      BasketItem basketItem = new FFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);

		      BigDecimal expectedTotalItemValue = new BigDecimal(9.60);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = basketItem.getTotalValueOfBasketItem();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);
		      assertEquals("FFTPOT", basketItem.getDiscountType());
	   } 
	   
	   //All Discounted items in one basket
	   
	  Customer customer = new Customer(12345, "Smith", "1 the High Street", "Bootle",
				  "Lancs", "BOO 12T", "01273 700349", "Smith@Bootle.com", "Foo", "Bar");

		 
	   @Test
	   public void allDiscountedItemsInSameBasket()
	   {
			  OrderBasket orderBasket = new OrderBasket(customer);
			  
	          int productID = 1;
		      String productName = "Old Knobler";
		      BigDecimal wholesalePrice = new BigDecimal(1.60);
		      BigDecimal recommendedRetailPrice = new BigDecimal(11.00);
		      int quantity = 5;
		      int formatID = 5;
		      int degreeOfRoastID = 2;
		      String description = "Old Knobler is the original classic";
		       
		      BasketItem basketItem = new FFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		      orderBasket.addItem(basketItem);
		   
	          productID = 2;
		      productName = "Robusta Crusta";
		      wholesalePrice = new BigDecimal(2.60);
		      recommendedRetailPrice = new BigDecimal(5.00);
		      quantity = 5;
		      formatID = 5;
		      degreeOfRoastID = 2;
		      description = "Old Knobler is the original classic";
		       
		      basketItem = new TFTPOTBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		      orderBasket.addItem(basketItem);
		      
	          productID = 3;
		      productName = "Java Lava";
		      wholesalePrice = new BigDecimal(3.60);
		      recommendedRetailPrice = new BigDecimal(7.00);
		      quantity = 3;
		      formatID = 5;
		      degreeOfRoastID = 2;
		      description = "Rock meltingly hot!";
		       
		      basketItem = new BOGOFBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description);
		      orderBasket.addItem(basketItem);
 		      
	          productID = 4;
		      productName = "Java Lava";
		      wholesalePrice = new BigDecimal(3.00);
		      recommendedRetailPrice = new BigDecimal(7.00);
		      quantity = 3;
		      formatID = 5;
		      degreeOfRoastID = 2;
		      int percentageDiscount = 10;
		      description = "Rock meltingly hot!";
		       
		      basketItem = new PercentageDiscountBasketItem(productID, productName, wholesalePrice, recommendedRetailPrice, quantity, formatID, degreeOfRoastID, description, percentageDiscount);
		      orderBasket.addItem(basketItem);

		      
		      BigDecimal expectedTotalItemValue = new BigDecimal(32.10);
		      expectedTotalItemValue = expectedTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      BigDecimal actualTotalItemValue = orderBasket.getBasketTotal();
		      actualTotalItemValue = actualTotalItemValue.setScale(2, RoundingMode.HALF_EVEN);
		      
		      assertEquals(expectedTotalItemValue, actualTotalItemValue);

	   }   

}
