package deansBeansBusinessObjects;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import deansBeansDataLayer.DeansBeansDBMySQLEngine;
import deansBeansDataLayer.SessionFactoryUtil;
import deansBeansDataLayer.models.Format;
import deansBeansDataLayer.models.Customer;
import deansBeansDataLayer.models.DegreesOfRoast;
import deansBeansDataLayer.models.Order;
import deansBeansDataLayer.models.OrderItem;
import deansBeansDataLayer.models.Product;

public class MySQLDeansBeansRepository implements IDeansBeansRepository
{

	DeansBeansDBMySQLEngine engine = new DeansBeansDBMySQLEngine();
    
    public List<Customer> getCustomers()
    {
	 	List<Customer> customers = null;
	 	customers = engine.getCustomers();
        return customers;
    }

    public List<Product> getProducts()
    {
	 	List<Product> products = null;
	 	products = engine.getProducts();
        return products;
    }
 
    public List<Format> getFormats()
    {
	 	List<Format> formats = null;
	 	formats = engine.getFormats();
        return formats;
    }

	@Override
	public List<Order> getOrdersForCustomer(int customerID) {
	 	List<Order> orders = null;
	 	orders = engine.getOrdersForCustomer(customerID);
        return orders;
    }

	@Override
	public List<OrderItem> getOrderItemsForOrder(int orderID) {
	 	List<OrderItem> orderItems = null;
	 	orderItems = engine.getOrderItemsForOrder(orderID);
        return orderItems;
	}
	

	@Override
	public Format getFormatByID(int formatID) {
		Format format = null;
		format = engine.getFormatByID(formatID);
		return format;
	}

	@Override
	public List<DegreesOfRoast> getDegreesOfRoast() {
	 	List<DegreesOfRoast> degreesOfRoast = null;
	 	degreesOfRoast = engine.getDegreesOfRoast();
        return degreesOfRoast;
	}

	@Override
	public DegreesOfRoast getDegreeOfRoastByID(int degreeOfRoastID) {
		DegreesOfRoast degreesOfRoast = null;
		degreesOfRoast = engine.getDegreeOfRoastByID(degreeOfRoastID);
		return degreesOfRoast;
	}

	@Override
	public int insertOrder(Order order) {
	 	return engine.insertOrder(order);
	}

	@Override
	public int insertOrderItem(OrderItem orderItem) {
	 	return engine.insertOrderItem(orderItem);
	}
    
	@Override
	public int saveOrderToDatabase(IOrderBasket orderBasket, Customer customer) {
		long millis = System.currentTimeMillis();
		Order order = new Order (customer.getCustomerID(),  new Date(millis), orderBasket.getBasketTotal(), 1);
		
		OrderItem orderItem;
		
		for (IBasketItem basketItem : orderBasket.getBasketItems()) {
			orderItem = new OrderItem (order, basketItem.getProductID(), basketItem.getTotalValueOfBasketItem(), basketItem.getQuantity(), basketItem.getFormatID(), basketItem.getDegreeOfRoastID());
			order.addOrderItem(orderItem); 
		}
	 	return engine.saveOrderToDatabase(order);
	}


}
