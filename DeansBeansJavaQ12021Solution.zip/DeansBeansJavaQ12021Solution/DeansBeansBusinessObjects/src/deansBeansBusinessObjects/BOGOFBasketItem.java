package deansBeansBusinessObjects;

import java.math.BigDecimal;

import deansBeansDataLayer.models.Format;

public class BOGOFBasketItem extends BasketItem {
    public BOGOFBasketItem(int productID, String productName, BigDecimal wholesalePrice, BigDecimal rrp, int quantity,  int formatID, int degreeOfRoastID, String description)
    {
    	super(productID, productName, wholesalePrice, rrp, quantity, formatID, degreeOfRoastID, description);
    }
    
    @Override
    public BigDecimal getTotalValueOfBasketItem() {
        return getQuantity() % 2 == 0? getWholesalePrice().multiply(new BigDecimal(getQuantity() / 2)): getWholesalePrice().multiply(new BigDecimal(getQuantity()/2 + 1));
    }

    @Override
    public String getDiscountType() {
        return "BOGOF";
    }
}
