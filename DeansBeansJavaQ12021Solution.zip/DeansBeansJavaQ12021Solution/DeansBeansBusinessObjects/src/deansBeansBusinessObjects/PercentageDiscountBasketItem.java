package deansBeansBusinessObjects;

import java.math.BigDecimal;
import java.math.RoundingMode;

import deansBeansDataLayer.models.Format;

public class PercentageDiscountBasketItem extends BasketItem {
    public PercentageDiscountBasketItem(int productID, String productName, BigDecimal wholesalePrice, BigDecimal rrp, int quantity,  int formatID, int degreeOfRoastID, String description, int percentageDiscount)
    {
    	super(productID, productName, wholesalePrice, rrp, quantity, formatID, degreeOfRoastID, description);
        this.setPercentageDiscount(percentageDiscount);
    }

    private int percentageDiscount;
    public int getPercentageDiscount() {
    	return percentageDiscount;
    }
    private void setPercentageDiscount(int percentageDiscount) {
    	this.percentageDiscount = percentageDiscount;
 
    }

    @Override
    public BigDecimal getTotalValueOfBasketItem() {
        return  (getWholesalePrice().multiply(new BigDecimal(getQuantity()).multiply((new BigDecimal(1).subtract(new BigDecimal(getPercentageDiscount()).divide(new BigDecimal(100)).setScale(2, RoundingMode.UP))))));
    }

    @Override
    public String getDiscountType() {
        return getPercentageDiscount() + "% Discount";
    }
}
