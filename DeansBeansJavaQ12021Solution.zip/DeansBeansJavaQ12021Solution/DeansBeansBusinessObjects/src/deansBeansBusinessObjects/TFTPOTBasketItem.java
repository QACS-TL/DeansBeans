package deansBeansBusinessObjects;

import java.math.BigDecimal;

public class TFTPOTBasketItem extends BasketItem {
    public TFTPOTBasketItem(int productID, String productName, BigDecimal wholesalePrice, BigDecimal rrp, int quantity,  int formatID, int degreeOfRoastID, String description)
    {
    	super(productID, productName, wholesalePrice, rrp, quantity, formatID, degreeOfRoastID, description);
    }
    
    @Override
    public BigDecimal getTotalValueOfBasketItem() {
        
    	return getWholesalePrice().multiply((new BigDecimal(getQuantity() / 3)).multiply(new BigDecimal(2)).add(new BigDecimal(getQuantity()).remainder(new BigDecimal(3))));
    	//return getQuantity() % 3 == 0? getWholesalePrice().multiply(new BigDecimal(getQuantity() / 2)): getWholesalePrice().multiply(new BigDecimal(getQuantity()/2 + 1));
    }

    @Override
    public String getDiscountType() {
        return "TFTPOT";
    }
}
