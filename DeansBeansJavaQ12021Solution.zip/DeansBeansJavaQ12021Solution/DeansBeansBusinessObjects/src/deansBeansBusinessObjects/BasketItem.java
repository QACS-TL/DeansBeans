package deansBeansBusinessObjects;
import java.math.BigDecimal;

import deansBeansDataLayer.models.Format;

public class BasketItem implements IBasketItem {
    private int productID;
    private String productName;
    private BigDecimal wholesalePrice;
    private BigDecimal recommendedRetailPrice;
    private int quantity;
    private int formatID;
    private int degreeOfRoastID;
    private String discountType = "";
    private String description;

    public BasketItem(int productID, String productName, BigDecimal wholesalePrice, BigDecimal recommendedRetailPrice, int quantity, int formatID, int roastID, String description) {
        this.setProductID(productID);
        this.setProductName(productName);
        this.setWholesalePrice(wholesalePrice);
        this.setRecommendedRetailPrice(recommendedRetailPrice);
        this.setQuantity(quantity);
        this.setFormatID(formatID);
        this.setDegreeOfRoastID(roastID);
        this.setDiscountType("");
        this.setDescription(description);
    }

	public int getProductID(){
        return productID;
    }
	
    private void setProductID(int productID) {
    	this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }
    
    private void setProductName(String productName) {
    	this.productName = productName;
    }
    
    public BigDecimal getWholesalePrice() {
        return wholesalePrice;
    }

    private void setWholesalePrice(BigDecimal wholesalePrice) {
    	if (wholesalePrice.compareTo(new BigDecimal(0)) <=  0 || wholesalePrice.compareTo(new BigDecimal(1000)) >= 0)
    		throw new IllegalArgumentException("wholesale price must be positive, greater than zero and less than 1000");
    	this.wholesalePrice = wholesalePrice;
    }

    public BigDecimal getRecommendedRetailPrice() {
        return recommendedRetailPrice;
    }

    private void setRecommendedRetailPrice(BigDecimal recommendedRetailPrice) {
    	if (recommendedRetailPrice.compareTo(new BigDecimal(0)) <=  0 || recommendedRetailPrice.compareTo(new BigDecimal(1000)) >= 0)
    		throw new IllegalArgumentException("recommendedRetail price must be positive, greater than zero and less than 1000");
    	this.recommendedRetailPrice = recommendedRetailPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    private void setQuantity(int quantity) {
        if (quantity <= 0 || quantity > 100)
        	throw new IllegalArgumentException("Quantity must be greater than zero and less than or equal to 100");
        this.quantity = quantity;
    }

	public int getFormatID() {
		return formatID;
	}

	private void setFormatID(int formatID) {
		this.formatID = formatID;
	}

	public int getDegreeOfRoastID() {
		return degreeOfRoastID;
	}

	private void setDegreeOfRoastID(int degreeOfRoastID) {
        if (degreeOfRoastID <= 0 || degreeOfRoastID > 6)
            throw new IllegalArgumentException("Degree of Roast must be greater than zero and less than or equal to 6");
		this.degreeOfRoastID = degreeOfRoastID;
	}

    public String getDiscountType() {
		return discountType;
	}

	private void setDiscountType(String discountType) {
		this.discountType = discountType;
	}

    public String getDescription() {
        return description;
    }
     
    private void setDescription(String description) {
        this.description = description;
    }
    
    public BigDecimal getTotalValueOfBasketItem(){
        BigDecimal totalPrice = wholesalePrice.multiply(new BigDecimal(quantity));
        return totalPrice;
     }
    
    public int increaseQuantity(int quantity) {
        if (quantity <= 0)
            throw new IllegalArgumentException("Quantity must be positive and greater than zero");
    	this.setQuantity(this.getQuantity() + quantity);
    	return this.getQuantity();
    }
    
    public int decreaseQuantity(int quantity) {
        if (quantity <= 0)
            throw new IllegalArgumentException("Quantity must be positive and greater than zero");
    	this.setQuantity(this.getQuantity() - quantity);
    	return this.getQuantity();
    }

	public int increaseDegreeOfRoast(int incrementalValue) {
        if (incrementalValue <= 0)
            throw new IllegalArgumentException("Quantity must be positive and greater than zero");
    	this.setDegreeOfRoastID(this.getDegreeOfRoastID() + incrementalValue);
    	return this.getDegreeOfRoastID();
	}

	public int decreaseDegreeOfRoast(int incrementalValue) {
        if (incrementalValue <= 0)
            throw new IllegalArgumentException("Quantity must be positive and greater than zero");
    	this.setDegreeOfRoastID(this.getDegreeOfRoastID() - incrementalValue);
    	return this.getDegreeOfRoastID();
	}


}