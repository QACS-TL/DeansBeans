package deansBeansBusinessObjects;

import java.math.BigDecimal;

public class FFTPOTBasketItem  extends BasketItem {
    public FFTPOTBasketItem(int productID, String productName, BigDecimal wholesalePrice, BigDecimal rrp, int quantity,  int formatID, int degreeOfRoastID, String description)
    {
    	super(productID, productName, wholesalePrice, rrp, quantity, formatID, degreeOfRoastID, description);
    }
    
    @Override
    public BigDecimal getTotalValueOfBasketItem() {
        
    	return getWholesalePrice().multiply((new BigDecimal(getQuantity() / 4)).multiply(new BigDecimal(3)).add(new BigDecimal(getQuantity()).remainder(new BigDecimal(4))));
    }

    @Override
    public String getDiscountType() {
        return "FFTPOT";
    }
}
